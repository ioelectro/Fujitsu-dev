==========================================================================
                   Template Project for MB90540 Series
==========================================================================

                        Warranty and Disclaimer 

 
The use of the deliverables (e.g. software, application examples, target 
boards, evaluation boards, starter kits, schematics, engineering samples 
of IC's etc.) is subject to the conditions of Fujitsu Microelectronics 
Europe GmbH ("FME") as set out in (i) the terms of the License Agreement 
and/or the Sale and Purchase Agreement under which agreements the Product 
has been delivered, (ii) the technical descriptions and (iii) all 
accompanying written materials. 

Please note that the deliverables are intended for and must only be used 
in an evaluation laboratory environment. 

The software deliverables are provided without charge and therefore 
provided on an as-is basis. The software deliverables are to be used 
exclusively in connection with FME products. 

Regarding hardware deliverables, FME warrants that they will be free from 
defects in material and workmanship under use and service as specified in 
the accompanying written materials for a duration of 1 year from the date 
of receipt by the customer. 

Should a hardware deliverable turn out to be defect, FME's entire 
liability and the customer's exclusive remedy shall be, at FME's sole 
discretion, either return of the purchase price and the license fee, or 
replacement of the hardware deliverable or parts thereof, if the 
deliverable is returned to FME in original packing and without further 
defects resulting from the customer's use or the transport. However, this 
warranty is excluded if the defect has resulted from an accident not 
attributable to FME, or abuse or misapplication attributable to the 
customer or any other third party not relating to FME or to unauthorised 
decompiling and/or reverse engineering and/or disassembling. 

FME does not warrant that the deliverables do not infringe any third party 
intellectual property right (IPR). In the event that the deliverables 
infringe a third party IPR it is the sole responsibility of the customer 
to obtain necessary licenses to continue the usage of the deliverable. 

In the event the software deliverables include the use of open source 
components, the provisions of the governing open source license agreement 
shall apply with respect to such software deliverables. 

To the maximum extent permitted by applicable law FME disclaims all other 
warranties, whether express or implied, in particular, but not limited to, 
warranties of merchantability and fitness for a particular purpose for 
which the deliverables are not designated. 

To the maximum extent permitted by applicable law, FME's liability is 
restricted to intention and gross negligence. FME is not liable for 
consequential damages. 

Should one of the above stipulations be or become invalid and/or 
unenforceable, the remaining stipulations shall stay in full effect. 

The contents of this document are subject to change without a prior 
notice, thus contact FME about the latest one. 

(V1.0) 


==========================================================================
               
History
Date        Ver     Author  Softune     Description
2099-07-26  1.0     HLO     V30L10      original version
2003-01-29  1.1     HW      V30L26R02   new header files
2003-09-02  1.2     HW      V30L29      new header- and asm-file
2004-04-16  1.3     HLO     V30L31      new start-up file
2006-09-06  1.4     CSC     V30L32      new start.asm 
2009-07-02  1.5     RLa     V30L35      new start-up file
2009-08-31  1.6     RLa     V30L35      new start.asm
==========================================================================

This is a project template for the MB90540 Series. It includes some basic 
settings for e.g. Linker, C-Compiler which must be checked and modified in 
detail, corresponding to the user application.
